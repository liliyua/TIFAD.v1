

from Automation.Config import pipelineConfig
from Automation.Pipeline import pipeline
from Log.LogToFile import useLogToFile
from Actions.spider_imageData import downloadInfo, execute_spider_imageData


class PipeLineManager_Dev:
    config: pipelineConfig

    def __init__(self, config: pipelineConfig):
        self.config = config

    def Execute(self, date: str):

        # 单条测试用代码
        p = pipeline(self.config, '20231001', downloadInfo(
            'http://124.16.184.48:6008/getdown/L4B/TIS/202310/KX10_TIS_20231001_E7.97_N44.81_202300405997_L4B.zip?md5=244y4-o-cRbiAz0YkjjeUQ&expires=1708448591', 'KX10_TIS_20231001_E7.97_N44.81_202300405997_L4B'))
        p.Execute()
