import os


class pipelineConfig:
    """配置类"""
    rawImagesDirPath: str = ""
    downloadImagePath: str = ""
    unzipImagesDirPath: str = ""
    linearStretchImagesDirPath: str = ""
    segmentImagesDirPath: str = ""
    yoloSaveDirPath: str = ""
    yoloModelPath: str = ""
    outputResultsPath: str = ""
    planeTablePath: str = ""
    validResultPath: str = ""
    logPath: str = ""
    segmentSize: int
    name: str

    def __init__(self, logPath: str, downloadImagePath: str, yoloModelPath: str, rawImagesDirPath: str, unzipImagesDirPath: str, segmentImagesDirPath: str, linearStretchImagesDirPath: str, yoloSaveDirPath: str, labelPositionPath: str, planeTablePath: str, validCorpPath: str, segmentSize: int = 700):
        self.logPath = logPath
        self.downloadImagePath = downloadImagePath
        self.rawImagesDirPath = rawImagesDirPath
        self.unzipImagesDirPath = unzipImagesDirPath
        self.segmentImagesDirPath = segmentImagesDirPath
        self.linearStretchImagesDirPath = linearStretchImagesDirPath
        self.yoloSaveDirPath = yoloSaveDirPath
        self.segmentSize = segmentSize
        self.yoloModelPath = yoloModelPath
        self.outputResultsPath = labelPositionPath
        self.planeTablePath = planeTablePath
        self.validResultPath = validCorpPath

    def __init__(self, root: str, yoloModelPath: str, segmentSize: int = 700):
        self.logPath = root
        self.yoloModelPath = yoloModelPath
        self.downloadImagePath = root+'/download'
        self.rawImagesDirPath = root+'/download'
        self.unzipImagesDirPath = root+"/unzip"
        self.segmentImagesDirPath = root+"/crop"
        self.linearStretchImagesDirPath = root+"/8bit"
        self.yoloSaveDirPath = root+"/yolo"
        self.outputResultsPath = root+"/results"
        self.planeTablePath = root+"/planeTable"
        self.validResultPath = self.outputResultsPath  # 与labelPosition相同，但子级还需要新建文件夹分类
        self.segmentSize = segmentSize
