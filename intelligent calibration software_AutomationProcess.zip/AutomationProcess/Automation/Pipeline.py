import os
import time
from Actions.downloadTarget import executeDownload
from Actions.linear_stretch import execute_linear_stretch
from Actions.spider_imageData import downloadInfo
from Actions.statistic import execute_comparision
from Actions.tif_LP import execute_tifLP
from Actions.tif_segment_crop import execute_tif_segment_crop
from Actions.yoloDetect import execute_yoloDetect
from Automation.Config import pipelineConfig
from Utils.unzip import execute_unzip


class pipeline:
    config: pipelineConfig
    url: str
    filename: str
    rawImagePath: str
    unzipSubFolder: str
    segmentSubFolder: str
    linearStretchSubfolder: str
    date: str
    yoloOutput: str
    labelsPositionPath: str
    segmentMap: dict

    def __init__(self, config: pipelineConfig, date: str, fileInfo: downloadInfo) -> bool:
        # initialize
        self.rawImagePath = ""
        self.unzipSubFolder = ""
        self.segmentSubFolder = ""
        self.linearStretchSubfolder = ""
        self.yoloOutput = ""
        self.labelsPositionPath = ""
        self.segmentMap = ""

        self.config = config
        self.date = date
        self.url = fileInfo.url
        self.filename = fileInfo.fileName

    def Execute(self) -> bool:
        """执行流水线操作"""
        try:
            # step 1 download----------------------------------------------------------------------------------------
            self.rawImagePath, self.name = executeDownload(
                self.url, self.config.rawImagesDirPath, 4)
            if (self.rawImagePath == ""):
                print("#数据下载异常,提前终止")
                return True
            print("#当前项目: " + self.name)

            # step 2 unzip-------------------------------------------------------------------------------------------------------
            self.unzipSubFolder = execute_unzip(
                self.rawImagePath, self.config.unzipImagesDirPath)

            # step 3 segmentation--------------------------------------------------------------------------------------------------
            self.segmentSubFolder, self.segmentMap = execute_tif_segment_crop(
                self.unzipSubFolder, self.config.segmentImagesDirPath, self.config.planeTablePath)
            if self.segmentSubFolder == "":
                print("#planeTable中无飞机,提前终止")
                return True

            # step 4 to8bit-------------------------------------------------------------------------------------------------------
            self.linearStretchSubfolder = execute_linear_stretch(
                self.segmentSubFolder, self.config.linearStretchImagesDirPath)

            # step 5 yolo detect---------------------------------------------------------------------------------------------------
            self.yoloOutput = execute_yoloDetect(self.linearStretchSubfolder,
                                                 f'{self.config.yoloSaveDirPath}/{self.date}',
                                                 self.name,
                                                 self.config.yoloModelPath)

            # step 6 calculate the position----------------------------------------------------------------------------------------
            labelsFolder = self.yoloOutput + '/labels'  # 定位到labels文件夹
            self.labelsPositionPath, positionInfoList = execute_tifLP(
                labelsFolder, self.segmentSubFolder, self.config.outputResultsPath, self.name)

            # step 7 result statistics---------------------------------------------------------------------------------------------
            execute_comparision(self.segmentMap,
                                self.name, self.config.planeTablePath, positionInfoList, self.segmentSubFolder, self.config.validResultPath, self.date)

        except Exception as e:
            print(e)
            return False

        return True
