
import os
import pandas as pd
import rasterio
from rasterio.transform import from_origin
from shapely.geometry import Point
from pyproj import Proj, transform
import numpy as np

# 主目录和飞机表格目录
# maindir = 'F:/迁移文件/fly_dataset/L4B/2023.10.9'
# plane_table_dir = 'E:/research/fly_dataset/planetable/planetable/202310/20231009'

maindir = r'F:\research\fly_dataset\unzip'  # Update this to your TIFF images directory
plane_table_dir = r'F:\research\fly_dataset\planetable\planetable\planetable\202310\20231001'  # Update this to your CSV files directory
outdir = r'F:\research\fly_dataset\crop'

# 遍历主目录下的所有子目录
for subdir in os.listdir(maindir):
    subdir_path = os.path.join(maindir, subdir)
    if os.path.isdir(subdir_path):
        for image_file in os.listdir(subdir_path):
            if image_file.endswith('.tiff'):
                image_path = os.path.join(subdir_path, image_file)

                # 分离文件名，用于构建表格路径
                name, _ = os.path.splitext(image_file)
                excel_file_path = os.path.join(plane_table_dir, f'{name}.csv')

                # 读取CSV文件
                df = pd.read_csv(excel_file_path)
                if df.empty or df.shape[0] < 2:
                    os.remove(excel_file_path)
                    print(f'Deleted empty table: {excel_file_path}')
                    try:
                        os.rmdir(subdir_path)
                        print(f'Deleted image folder: {subdir_path}')
                    except OSError as e:
                        print(f'Error: {e.strerror}')
                    continue

                # 筛选大于4000米的行
                df_filtered = df[df['CALIBRATED ALTITUDE(m)'] > 4000]

                # 重新写入筛选后的CSV
                df_filtered.to_csv(excel_file_path, index=False)

                from rasterio.warp import transform

                # 使用rasterio打开图像
                with rasterio.open(image_path) as src:
                    # 获取图像的crs和transform属性
                    crs = src.crs
                    affine_transform = src.transform

                    # 遍历筛选后的DataFrame
                    for index, row in df_filtered.iterrows():
                        lat, lon = row['LATITUDE'], row['LONGITUDE']

                        # 将地理坐标转换为图像中的行列坐标
                        x, y = transform('epsg:4326', crs, [lon], [lat])
                        row, col = ~affine_transform * (x[0], y[0])

                        # 计算剪裁的窗口，注意这里的行列坐标需要根据实际情况进行调整
                        window = rasterio.windows.Window(col - 350, row - 350, 700, 700)

                        # 读取窗口内的数据
                        clip = src.read(window=window)

                        # 保存剪裁后的图像
                        clip_path = os.path.join(outdir, f'{name}_head_{index}.tif')
                        with rasterio.open(
                                clip_path,
                                'w',
                                driver='GTiff',
                                height=clip.shape[1],
                                width=clip.shape[2],
                                count=src.count,
                                dtype=clip.dtype,
                                crs=src.crs,
                                transform=rasterio.windows.transform(window, affine_transform)
                        ) as clip_dst:
                            clip_dst.write(clip)
