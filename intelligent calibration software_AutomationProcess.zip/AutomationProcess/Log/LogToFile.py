
from Utils.fileUtils import ensureDir


def useLogToFile(path='./'):
    '''
    控制台重定向打印到日志，勿多次执行
    '''
    import sys
    import os
    import sys
    import datetime

    class Logger(object):
        def __init__(self, filename="Default.log", path="./"):
            ensureDir(path)
            self.terminal = sys.stdout
            self.path = os.path.join(path, filename)
            self.log = open(self.path, "a", encoding='utf8',)
            print("save:", os.path.join(self.path, filename))

        def write(self, message: str):
            # 格式统一
            if message.startswith('#'):
                message = message.lstrip('#')
                message = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + \
                    "] " + message
            self.terminal.write(message)
            self.log.write(message)
            self.flush()

        def flush(self):
            self.log.flush()

    fileName = datetime.datetime.now().strftime('day'+'%Y_%m_%d')
    sys.stdout = Logger(fileName + '.log', path)
    print("#"+" Program initialized. ".center(60, '*'))
