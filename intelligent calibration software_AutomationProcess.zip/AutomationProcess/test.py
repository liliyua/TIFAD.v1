import csv
import os
from Actions.tif_LP import execute_tifLP

labelDirPath = "D:/ap/yolo/2024-01-05/KX10_TIS_20240105_E145.99_S42.62_202400001753_L4B/labels"
imagesDirPath = "D:/ap/crop/KX10_TIS_20240105_E145.99_S42.62_202400001753_L4B"


#execute_tifLP(labelDirPath, imagesDirPath)


csvReader = csv.reader(
    open("D:/ap/planeTable/KX10_TIS_20231001_E7.97_N44.81_202300405997_L4B.csv", encoding='utf-8'))

lineCount = 0
latIndex = 0
lonIndex = 0
for row in csvReader:
    if lineCount == 0:
        print(row)
        latIndex = row.index('LATITUDE')
        lonIndex = row.index('LONGITUDE')
    else:
        print(row[latIndex]+","+row[lonIndex])
    lineCount += 1
