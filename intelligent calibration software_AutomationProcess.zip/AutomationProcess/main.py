import argparse
import pandas as pd
from Automation.Pipeline import pipelineConfig
from Automation.PipelineManager import PipeLineManager
from Automation.PipelineManager_Dev import PipeLineManager_Dev
from Log.LogToFile import useLogToFile


# 参数输入
parser = argparse.ArgumentParser()
parser.add_argument('--dateStart', type=str, default=None)  # 日期开始
parser.add_argument('--dateEnd', type=str, default=None)  # 日期结束
parser.add_argument('--root', type=str, default=None)  # 根目录
args = parser.parse_args()
dateStart = args.dateStart
dateEnd = args.dateEnd
root = args.root

# 自定义参数修正，若在外部以命令行执行，注释该部分代码
root = "d:/ap"  # 根目录指定
dateStart = "2023-09-01"  # 开始日期
dateEnd = "2023-09-02"  # 结束日期

# 实例化配置类
config = pipelineConfig(
    root, "D:/ap/best.pt")

# 日志注册
useLogToFile(config.logPath)

# 日期段生成
print(f"#version 20240229155")
print(f"#日期范围,开始 {dateStart}，结束 {dateEnd}")
dataList = [pd.Timestamp(x).strftime("%Y-%m-%d")
            for x in pd.date_range(dateStart, dateEnd).values]

# 执行日期任务
for date in dataList:
    #manager = PipeLineManager_Dev(config)
    manager = PipeLineManager(config)
    manager.Execute(date)
