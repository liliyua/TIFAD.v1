
import os


def getFileNameWithoutExtensionFromFileName(fileName: str) -> str:
    #fileNameNoExtension, _ = fileName.rsplit('.', 1)[0]
    fileNameNoExtension, _ = os.path.splitext(fileName)
    return fileNameNoExtension


def getFileNameWithoutExtensionFromPath(filePath: str) -> str:
    fileName = os.path.basename(filePath)
    return getFileNameWithoutExtensionFromFileName(fileName)


def ensureDir(dir: str) -> str:
    """核查目录，若不存在则创建目录，同时返回目录路径"""
    if not os.path.exists(dir):
        os.makedirs(dir)
    return dir
