import argparse
import os
import zipfile

from Utils.fileUtils import ensureDir, getFileNameWithoutExtensionFromPath


def execute_unzip(zipPath: str, outputDir: str) -> str:
    """解压zipPath目标文件，返回加压后子路径"""
    print("#解压数据: "+zipPath)

    unzipFolder = ensureDir(
        outputDir+"/"+getFileNameWithoutExtensionFromPath(zipPath))

    # 读取压缩文件

    file = zipfile.ZipFile(zipPath)
    # 解压文件
    file.extractall(unzipFolder)
    # 关闭文件流
    file.close()
    print("#解压完成:" + unzipFolder)
    return unzipFolder


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('--zipPath', type=str, default=None)
    parser.add_argument('--outputDir', type=str, default=None)
    args = parser.parse_args()

    zipPath = args.zipPath
    outputDir = args.outputDir
    execute_unzip(zipPath, outputDir)
