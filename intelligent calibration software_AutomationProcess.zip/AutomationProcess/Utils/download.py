

from email.quoprimime import unquote
import os
import time
import requests

from Utils.fileUtils import ensureDir


def get_file_name(url, headers):
    filename = ''
    if 'Content-Disposition' in headers and headers['Content-Disposition']:
        disposition_split = headers['Content-Disposition'].split(';')
        if len(disposition_split) > 1:
            if disposition_split[1].strip().lower().startswith('filename='):
                file_name = disposition_split[1].split('=')
                if len(file_name) > 1:
                    filename = unquote(file_name[1])
    if not filename and os.path.basename(url):
        filename = os.path.basename(url).split("?")[0]
    if not filename:
        return time.time()
    return filename


def execute_downloadFile(url: str, saveDir: str, filename: str = ""):
    """下载url地址中的文件,使用默认文件名时，返回下载后路径"""
    print("#正在下载: "+url)

    res = requests.get(url, stream=True)

    if filename == "":
        filename = get_file_name(url, res.headers)
    path = saveDir + "/" + filename

    if (not os.path.exists(path)):
        ensureDir(os.path.dirname(path))
        with open(path, "wb") as pyFile:  # 绝对路径如'C:/xx\down/'
            for chunk in res.iter_content(chunk_size=1024*4):  # 4k
                if chunk:
                    pyFile.write(chunk)
    else:
        print(f"#检测到本地文件已存在，跳过下载 {path}")
    return path, os.stat(path).st_size
